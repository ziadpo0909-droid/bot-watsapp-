# ESCANOR V3

Core جديد نظيف + Features مختارة من V2 (كمرجع فقط) + Telegram Control Center + Multi-instance + Security by design.

## 📄 اقرأ `REPORT.md` أول حاجة — فيه بالظبط إيه المُنفَّذ والمُختبَر فعليًا، وإيه اللي لسه محتاج اختبار حقيقي على الـVPS.

## تشغيل سريع

```bash
npm install
npm test                 # 55 اختبار تلقائي (لازم يعدوا كلهم)
bash scripts/static-audit.sh
cp .env.example .env     # املأ القيم
node scripts/manual-whatsapp-check.js <رقمك>   # اختبار اتصال WhatsApp حقيقي
pm2 start ecosystem.config.js                    # تشغيل الـTelegram installer في production
```

## الوضع السابق (تاريخي)



- Engine: `@whiskeysockets/baileys@6.7.24` (مثبّت Exact، بدون `^`/`~`، بدون GitHub).
- `src/whatsapp/baileys-adapter.js` هو **الملف الوحيد** المسموح له يعمل `import` من `@whiskeysockets/baileys`. بيرجّع أحداث generic (`message`, `connection-open`, `pairing-code`...) وبيانات متطبّعة (normalized) — مش أشكال بيانات Baileys الخام. الـCore والـPlugins مستقبلًا هيتكلموا بس مع `src/whatsapp/index.js` (`createWhatsAppEngine`).
- **الاختبار (`scripts/manual-whatsapp-check.js`) لازم يتشغّل على الـVPS مش هنا** — الـsandbox بتاعي مقطوع عن الإنترنت ومفيش رقم واتساب حقيقي أقدر أعمله pairing بيه. تشغيل:
  ```bash
  npm install
  node scripts/manual-whatsapp-check.js <رقمك بصيغة دولية>
  ```
  البنود المطلوب تتأكد منها (السكريبت بيطبعها لحظة بلحظة): Connection, Pairing Code, استقبال رسالة, إرسال رد, Group metadata + groupParticipantsUpdate, Session persistence (شغّل تاني من غير ما تمسح `instances/test-phase2/session`), Disconnect/Reconnect.
- **متبدأش Phase 5 (نقل الـPlugins) قبل ما البنود دي كلها تعدي بنجاح على الـVPS.**

## الحالة السابقة: Phase 1 — Repository + Structure + Env + Lockfile ✅

هيكل المشروع (زي ما هو في `ESCANOR_V3_DEVELOPER_SPEC.md`):

```
ESCANOR-V3/
├── src/
│   ├── core/        ← Phase 3: Event Router / Permissions / Command Registry / Plugin Loader
│   ├── whatsapp/     ← Phase 2: Adapter فوق WhatsApp Engine (لسه ما اتحددش)
│   ├── plugins/      ← Phase 5: Feature migration من V2
│   ├── commands/     ← Phase 3
│   ├── security/     ← Sanitizer, permission checks, allowlists
│   └── config/       ← Phase 4: Config schema لكل instance
├── installer/         ← Phase 6/7: Telegram User + Developer Panel
│   ├── bot.js
│   ├── auth/
│   ├── handlers/
│   ├── services/
│   └── keyboards/
├── instances/          ← Phase 4: instance_XXX/{session,config,data,logs}
├── data/                ← SQLite database
├── logs/
├── package.json
├── .env.example
└── .gitignore
```

## مهم — لسه ما اتعملش

- **لا يوجد WhatsApp Engine مثبت بعد.** V2 كانت بتعتمد على `esewsub` من رابط GitHub رجع 404 ومفيش نسخة مثبتة نقدر نتحقق منها — قرار V3 هو التوقف عن الاعتماد على الديبندنسي دي خالص. اختيار الـEngine البديل (موثوق، منشور على npm الرسمي، وقابل للتثبيت على commit/version ثابت) هو أول خطوة في **Phase 2**، ولسه محتاج قرار/موافقة قبل ما يتضاف لـ`package.json`.
- `package-lock.json` هيتولد تلقائيًا أول ما تتضاف أي dependency حقيقية (Phase 2 فصاعدًا) — دلوقتي فيه `dotenv` بس كنقطة بداية.
- V2 (`Escanor-v2-main`) بتتفضل موجودة **كمرجع Features فقط** (Phase 5) — مفيش كود منها بيتنسخ مباشرة هنا.

## القاعدة الأهم

لا تعيد كتابة 300+ Plugin دفعة واحدة. الترتيب: WhatsApp Engine → Adapter → Core → Instance Manager → Permissions → Plugin System → V2 Feature Migration → Telegram Panels → PM2 → Security Audit → Production.
