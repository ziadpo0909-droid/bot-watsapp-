/**
 * src/config/schema.js
 * الشكل الافتراضي لإعدادات كل instance + دالة تحقق بسيطة (بدون مكتبة خارجية).
 */

export const DEFAULT_CONFIG = {
  instanceId: null,
  botName: 'ESCANOR',
  prefix: '.',
  owners: [],           // أرقام واتساب (JIDs) بصلاحية Owner على مستوى الـinstance
  enabledPlugins: {
    owner: true,
    group: true,
    misc: true,
  },
  protection: {
    antilink: false,
    antispam: false,
  },
  createdAt: null,
  updatedAt: null,
};

const STRING_FIELDS = ['botName', 'prefix'];
const ARRAY_FIELDS = ['owners'];

/**
 * تحقق بسيط من شكل الـconfig قبل الحفظ. بيرجع { valid, errors }.
 * مش بيرفض حقول زيادة (forward-compatible)، بس بيتأكد من النوع الأساسي للحقول المعروفة.
 */
export function validateConfig(config) {
  const errors = [];
  if (typeof config !== 'object' || config === null) {
    return { valid: false, errors: ['config لازم يكون object'] };
  }
  for (const field of STRING_FIELDS) {
    if (field in config && typeof config[field] !== 'string') {
      errors.push(`${field} لازم يكون string`);
    }
  }
  for (const field of ARRAY_FIELDS) {
    if (field in config && !Array.isArray(config[field])) {
      errors.push(`${field} لازم يكون array`);
    }
  }
  if (config.prefix !== undefined && config.prefix.length !== 1) {
    errors.push('prefix لازم يكون حرف واحد بس');
  }
  return { valid: errors.length === 0, errors };
}

export function mergeWithDefaults(partial = {}) {
  return {
    ...structuredClone(DEFAULT_CONFIG),
    ...partial,
    enabledPlugins: { ...DEFAULT_CONFIG.enabledPlugins, ...(partial.enabledPlugins || {}) },
    protection: { ...DEFAULT_CONFIG.protection, ...(partial.protection || {}) },
  };
}
