/**
 * src/config/config-manager.js
 * قراءة/كتابة settings.json لكل instance. الملف ده بس اللي بيلمس ملفات الإعدادات
 * على القرص — أي كود تاني (Core, Telegram installer) بيستخدم الدوال دي بس.
 *
 * ملحوظة أمان: الدوال دي متخصصاش أبدًا في التعامل مع Secrets (API keys, tokens).
 * دي بتتخزن في .env بس، ومتتحطش في settings.json ولا تترجع من getPublicConfig().
 */

import fs from 'node:fs/promises';
import path from 'node:path';
import { DEFAULT_CONFIG, validateConfig, mergeWithDefaults } from './schema.js';

function settingsPath(instanceDir) {
  return path.join(instanceDir, 'config', 'settings.json');
}

export async function loadConfig(instanceDir) {
  const file = settingsPath(instanceDir);
  try {
    const raw = await fs.readFile(file, 'utf-8');
    return mergeWithDefaults(JSON.parse(raw));
  } catch (err) {
    if (err.code === 'ENOENT') return mergeWithDefaults();
    throw err;
  }
}

export async function saveConfig(instanceDir, config) {
  const { valid, errors } = validateConfig(config);
  if (!valid) {
    throw new Error(`config غير صالح: ${errors.join(', ')}`);
  }
  const file = settingsPath(instanceDir);
  await fs.mkdir(path.dirname(file), { recursive: true });
  const toSave = { ...config, updatedAt: new Date().toISOString() };
  // كتابة atomic: نكتب لملف مؤقت وبعدين rename، عشان ميحصلش corruption لو حصل crash نص الكتابة
  const tmp = `${file}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(toSave, null, 2), 'utf-8');
  await fs.rename(tmp, file);
  return toSave;
}

export async function createInitialConfig(instanceDir, instanceId, overrides = {}) {
  const config = mergeWithDefaults({
    ...overrides,
    instanceId,
    createdAt: new Date().toISOString(),
  });
  return saveConfig(instanceDir, config);
}

/** نسخة آمنة للعرض على Telegram — بترجع كل حاجة ماعدا أي حقل ممكن يكون حساس مستقبلًا */
export function getPublicConfig(config) {
  const { ...safe } = config;
  return safe; // حاليًا settings.json مفيهوش secrets أصلًا، لكن الدالة دي بقت نقطة تحكم واحدة لو اتضاف حقل حساس بعدين
}
