/**
 * src/whatsapp/baileys-adapter.js
 *
 * ده الملف الوحيد المسموح له يعمل import مباشر لـ @whiskeysockets/baileys.
 * أي حاجة تانية في المشروع (Core, Plugins, Telegram installer) لازم تتكلم
 * مع WhatsApp عن طريق الـ interface العام اللي هنا، مش عن طريق Baileys نفسها.
 *
 * السبب: لو غيّرنا الـ Engine يومًا (Baileys → حاجة تانية)، الملف ده بس
 * اللي هيتغيّر. باقي المشروع (300+ Plugin مستقبلًا) هيفضل شغال زي ما هو.
 */

import { EventEmitter } from 'node:events';
import path from 'node:path';
import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
} from '@whiskeysockets/baileys';

/**
 * الأحداث اللي بيبعتها الـ Adapter للـ Core (كلها Engine-agnostic):
 *   - 'qr'                        (qrString)
 *   - 'pairing-code'              (code)
 *   - 'connection-open'           ()
 *   - 'connection-close'          ({ shouldReconnect, reason })
 *   - 'message'                   (normalizedMessage)
 *   - 'group-participants-update' ({ groupId, participants, action })
 *   - 'creds-updated'             ()
 */
export class BaileysAdapter extends EventEmitter {
  /**
   * @param {object} opts
   * @param {string} opts.instanceDir - مسار فولدر الـ instance (فيه session/ جواه)
   * @param {string} [opts.phoneNumber] - رقم الواتساب لطلب Pairing Code (لو مفيش، بيرجع QR بدل الكود)
   */
  constructor({ instanceDir, phoneNumber = null }) {
    super();
    if (!instanceDir) throw new Error('instanceDir مطلوب');
    this.instanceDir = instanceDir;
    this.sessionDir = path.join(instanceDir, 'session');
    this.phoneNumber = phoneNumber;
    this.sock = null;
    this._pairingRequested = false;
  }

  async connect() {
    const { state, saveCreds } = await useMultiFileAuthState(this.sessionDir);
    const { version } = await fetchLatestBaileysVersion();

    this.sock = makeWASocket({
      version,
      auth: state,
      printQRInTerminal: false, // بنبعت الـ QR/Code عن طريق event بس، مش عن طريق Console
    });

    this.sock.ev.on('creds.update', async () => {
      await saveCreds();
      this.emit('creds-updated');
    });

    this.sock.ev.on('connection.update', async (update) => {
      const { connection, qr, lastDisconnect } = update;

      if (qr && !this.phoneNumber) {
        this.emit('qr', qr);
      }

      if (connection === 'open') {
        this.emit('connection-open');
      }

      if (connection === 'close') {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
        this.emit('connection-close', {
          shouldReconnect,
          reason: statusCode ?? 'unknown',
        });
      }

      // Pairing Code: لازم الـ socket يبقى موجود ومسجّل الأول، وبنطلبه مرة واحدة بس
      if (
        this.phoneNumber &&
        !this._pairingRequested &&
        !this.sock.authState.creds.registered
      ) {
        this._pairingRequested = true;
        try {
          const code = await this.sock.requestPairingCode(this.phoneNumber);
          this.emit('pairing-code', code);
        } catch (err) {
          this.emit('connection-close', {
            shouldReconnect: false,
            reason: `pairing-request-failed: ${err.message}`,
          });
        }
      }
    });

    this.sock.ev.on('messages.upsert', ({ messages, type }) => {
      if (type !== 'notify') return;
      for (const raw of messages) {
        this.emit('message', this._normalizeMessage(raw));
      }
    });

    this.sock.ev.on('group-participants.update', (event) => {
      this.emit('group-participants-update', {
        groupId: event.id,
        participants: event.participants,
        action: event.action, // add | remove | promote | demote
      });
    });

    return this;
  }

  /** بيرجع نسخة مبسّطة من الرسالة، مش الـ Baileys raw object، عشان الـCore ميعتمدش على شكل بيانات Baileys */
  _normalizeMessage(raw) {
    return {
      id: raw.key?.id,
      chatId: raw.key?.remoteJid,
      fromMe: raw.key?.fromMe ?? false,
      senderId: raw.key?.participant || raw.key?.remoteJid,
      timestamp: raw.messageTimestamp,
      textBody:
        raw.message?.conversation ||
        raw.message?.extendedTextMessage?.text ||
        raw.message?.imageMessage?.caption ||
        raw.message?.videoMessage?.caption ||
        null,
      mentionedJids:
        raw.message?.extendedTextMessage?.contextInfo?.mentionedJid ||
        raw.message?.imageMessage?.contextInfo?.mentionedJid ||
        [],
      _raw: raw, // لو Plugin محتاج تفاصيل أعمق، متاحة هنا، لكن الاستخدام المفضّل هو الحقول اللي فوق
    };
  }

  async sendMessage(chatId, content) {
    if (!this.sock) throw new Error('مش متصل — نادي connect() الأول');
    return this.sock.sendMessage(chatId, content);
  }

  async getGroupMetadata(groupId) {
    if (!this.sock) throw new Error('مش متصل — نادي connect() الأول');
    return this.sock.groupMetadata(groupId);
  }

  /** action: 'add' | 'remove' | 'promote' | 'demote' — دي بتستخدم لأوامر kick/promote/demote */
  async updateGroupParticipants(groupId, participantIds, action) {
    if (!this.sock) throw new Error('مش متصل — نادي connect() الأول');
    const allowed = ['add', 'remove', 'promote', 'demote'];
    if (!allowed.includes(action)) {
      throw new Error(`action غير مسموح: ${action}`);
    }
    return this.sock.groupParticipantsUpdate(groupId, participantIds, action);
  }

  async disconnect() {
    if (!this.sock) return;
    await this.sock.logout().catch(() => {});
    this.sock.end(undefined);
    this.sock = null;
  }
}

/** الـCore والـPlugins بيستخدموا الدالة دي بس — مش الكلاس مباشرة، ومش أي import من baileys */
export function createWhatsAppEngine(opts) {
  return new BaileysAdapter(opts);
}
