/**
 * src/whatsapp/index.js
 *
 * نقطة الدخول العامة لطبقة WhatsApp. الـCore والـPlugins بيعملوا:
 *   import { createWhatsAppEngine } from '../whatsapp/index.js'
 * وميعملوش import مباشر لـ baileys-adapter.js ولا لـ @whiskeysockets/baileys.
 */
export { createWhatsAppEngine } from './baileys-adapter.js';
