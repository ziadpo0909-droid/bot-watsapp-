export default {
  command: ['kick', 'طرد'],
  minRole: 'admin',
  description: 'يطرد عضو من الجروب (Admin/Owner فقط) — .kick @user',
  async execute(ctx) {
    if (!ctx.message.chatId.endsWith('@g.us')) {
      return ctx.engine.sendMessage(ctx.message.chatId, { text: '❌ الأمر ده للجروبات بس' });
    }
    const target = ctx.mentionedJids?.[0];
    if (!target) {
      return ctx.engine.sendMessage(ctx.message.chatId, { text: '❌ استخدم: .kick مع منشن للعضو' });
    }
    await ctx.engine.updateGroupParticipants(ctx.message.chatId, [target], 'remove');
    await ctx.engine.sendMessage(ctx.message.chatId, { text: '✅ تم الطرد' });
  },
};
