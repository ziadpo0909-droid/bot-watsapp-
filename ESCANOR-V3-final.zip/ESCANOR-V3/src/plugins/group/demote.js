export default {
  command: ['demote', 'تنزيل'],
  minRole: 'admin',
  description: 'يشيل صلاحية أدمن من عضو (Admin/Owner فقط) — .demote @user',
  async execute(ctx) {
    if (!ctx.message.chatId.endsWith('@g.us')) {
      return ctx.engine.sendMessage(ctx.message.chatId, { text: '❌ الأمر ده للجروبات بس' });
    }
    const target = ctx.mentionedJids?.[0];
    if (!target) {
      return ctx.engine.sendMessage(ctx.message.chatId, { text: '❌ استخدم: .demote مع منشن للعضو' });
    }
    await ctx.engine.updateGroupParticipants(ctx.message.chatId, [target], 'demote');
    await ctx.engine.sendMessage(ctx.message.chatId, { text: '✅ تم تنزيل الصلاحية' });
  },
};
