export default {
  command: ['groupinfo', 'معلومات_الجروب'],
  minRole: 'member',
  description: 'يعرض معلومات الجروب الحالي',
  async execute(ctx) {
    if (!ctx.message.chatId.endsWith('@g.us')) {
      return ctx.engine.sendMessage(ctx.message.chatId, { text: '❌ الأمر ده للجروبات بس' });
    }
    const meta = await ctx.engine.getGroupMetadata(ctx.message.chatId);
    const text =
      `📌 *${meta.subject}*\n` +
      `👥 الأعضاء: ${meta.participants.length}\n` +
      `🆔 ${meta.id}`;
    await ctx.engine.sendMessage(ctx.message.chatId, { text });
  },
};
