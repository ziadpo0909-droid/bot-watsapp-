export default {
  command: ['promote', 'ترقية'],
  minRole: 'admin',
  description: 'يرقّي عضو لأدمن (Admin/Owner فقط) — .promote @user',
  async execute(ctx) {
    if (!ctx.message.chatId.endsWith('@g.us')) {
      return ctx.engine.sendMessage(ctx.message.chatId, { text: '❌ الأمر ده للجروبات بس' });
    }
    const target = ctx.mentionedJids?.[0];
    if (!target) {
      return ctx.engine.sendMessage(ctx.message.chatId, { text: '❌ استخدم: .promote مع منشن للعضو' });
    }
    await ctx.engine.updateGroupParticipants(ctx.message.chatId, [target], 'promote');
    await ctx.engine.sendMessage(ctx.message.chatId, { text: '✅ تمت الترقية' });
  },
};
