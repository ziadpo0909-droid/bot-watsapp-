export default {
  command: ['help', 'مساعدة', 'menu'],
  minRole: 'member',
  description: 'يعرض قائمة الأوامر المتاحة',
  async execute(ctx) {
    const commands = ctx.registry.list();
    const byCategory = {};
    for (const cmd of commands) {
      byCategory[cmd.category] ??= [];
      byCategory[cmd.category].push(Array.isArray(cmd.command) ? cmd.command[0] : cmd.command);
    }
    let text = `📋 *${ctx.config.botName} — الأوامر المتاحة*\n\n`;
    for (const [category, names] of Object.entries(byCategory)) {
      text += `*${category}:*\n${names.map((n) => `${ctx.config.prefix}${n}`).join(', ')}\n\n`;
    }
    await ctx.engine.sendMessage(ctx.message.chatId, { text });
  },
};
