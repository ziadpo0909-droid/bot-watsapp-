export default {
  command: ['ping', 'بينج'],
  minRole: 'member',
  description: 'يتأكد إن البوت شغال ويقيس زمن الرد',
  async execute(ctx) {
    const start = Date.now();
    await ctx.engine.sendMessage(ctx.message.chatId, { text: '🏓 Pong...' });
    const ms = Date.now() - start;
    await ctx.engine.sendMessage(ctx.message.chatId, { text: `✅ الرد استغرق ${ms}ms` });
  },
};
