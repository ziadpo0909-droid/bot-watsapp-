import { saveConfig } from '../../config/config-manager.js';

export default {
  command: ['setprefix'],
  minRole: 'owner',
  description: 'يغيّر الـprefix بتاع البوت (Owner فقط)',
  async execute(ctx) {
    const newPrefix = ctx.args[0];
    if (!newPrefix || newPrefix.length !== 1) {
      return ctx.engine.sendMessage(ctx.message.chatId, { text: '❌ استخدم: .setprefix <حرف واحد>' });
    }
    const updated = { ...ctx.config, prefix: newPrefix };
    await saveConfig(ctx.instanceDir, updated);
    await ctx.engine.sendMessage(ctx.message.chatId, { text: `✅ الـprefix اتغيّر لـ "${newPrefix}"` });
  },
};
