/**
 * src/core/index.js
 * بيشغّل "Core" واحد لـinstance واحد: بياخد engine (من src/whatsapp) + config + plugins،
 * ويربطهم مع بعض. الملف ده هو الحد الفاصل — أي حاجة جوه src/plugins بتستقبل ctx بس،
 * مش بتشوف Baileys ولا حتى الـAdapter مباشرة إلا عن طريق ctx.engine (اللي واجهته generic).
 */

import path from 'node:path';
import { loadPlugins } from './plugin-loader.js';
import { parseCommand } from './command-registry.js';
import { resolveRole, hasPermission } from './permissions.js';
import { loadConfig } from '../config/config-manager.js';
import { sanitizeForLog } from '../security/sanitizer.js';

const PLUGINS_DIR = path.join(new URL('.', import.meta.url).pathname, '..', 'plugins');

/**
 * @param {object} opts
 * @param {string} opts.instanceId
 * @param {string} opts.instanceDir
 * @param {import('../whatsapp/baileys-adapter.js').BaileysAdapter} opts.engine - جاهز بالفعل (اتعمله connect() برة)
 * @param {(entry: object) => void} [opts.onLog] - callback اختياري لتسجيل الأحداث (audit/logs)
 */
export async function startCore({ instanceId, instanceDir, engine, onLog = () => {} }) {
  const config = await loadConfig(instanceDir);
  const { registry, loaded, skipped, failed } = await loadPlugins(PLUGINS_DIR, config.enabledPlugins);

  onLog({
    level: 'info',
    instanceId,
    message: `Plugins loaded: ${loaded.length}, skipped: ${skipped.length}, failed: ${failed.length}`,
  });
  for (const f of failed) {
    onLog({ level: 'error', instanceId, message: sanitizeForLog(`فشل تحميل plugin: ${f.category}/${f.file} — ${f.reason}`) });
  }

  engine.on('message', async (message) => {
    try {
      await handleMessage({ message, engine, config, registry, instanceId, instanceDir, onLog });
    } catch (err) {
      onLog({ level: 'error', instanceId, message: sanitizeForLog(`خطأ أثناء معالجة رسالة: ${err.message}`) });
    }
  });

  return { registry, config, loaded, skipped, failed };
}

async function handleMessage({ message, engine, config, registry, instanceId, instanceDir, onLog }) {
  if (message.fromMe || !message.textBody) return;

  const parsed = parseCommand(message.textBody, config.prefix);
  if (!parsed) return;

  const command = registry.get(parsed.name);
  if (!command) return;

  let groupMetadata = null;
  if (message.chatId.endsWith('@g.us')) {
    groupMetadata = await engine.getGroupMetadata(message.chatId).catch(() => null);
  }

  const role = resolveRole(message.senderId, config, groupMetadata);
  const minRole = command.minRole || 'member';

  if (!hasPermission(role, minRole)) {
    await engine.sendMessage(message.chatId, { text: `❌ محتاج صلاحية ${minRole} على الأقل` });
    return;
  }

  const ctx = {
    message,
    engine,
    config,
    registry,
    role,
    args: parsed.args,
    text: parsed.text,
    mentionedJids: message.mentionedJids || [],
    groupMetadata,
    instanceId,
    instanceDir,
  };

  onLog({ level: 'info', instanceId, message: `أمر: ${parsed.name} من ${message.senderId}` });
  await command.execute(ctx);
}
