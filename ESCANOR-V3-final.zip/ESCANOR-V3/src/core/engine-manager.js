/**
 * src/core/engine-manager.js
 * بيدير دورة حياة الاتصال بـWhatsApp لـinstance واحد: يعمل connect، يشغّل الـCore
 * فوقه مرة واحدة، وبيتعامل مع قطع الاتصال بـExponential Backoff بدل ما يعيد المحاولة
 * كل ثانية أو يوقف نهائي.
 */

import { createWhatsAppEngine } from '../whatsapp/index.js';
import { startCore } from './index.js';
import { sanitizeForLog } from '../security/sanitizer.js';

const MAX_BACKOFF_MS = 60_000;
const BASE_BACKOFF_MS = 2_000;

export class EngineManager {
  /**
   * @param {object} opts
   * @param {string} opts.instanceId
   * @param {string} opts.instanceDir
   * @param {string} [opts.phoneNumber]
   * @param {(entry: object) => void} [opts.onLog]
   * @param {(status: object) => void} [opts.onStatusChange] - عشان Telegram installer يعرض الحالة/الـpairing code
   */
  constructor({ instanceId, instanceDir, phoneNumber = null, onLog = () => {}, onStatusChange = () => {} }) {
    this.instanceId = instanceId;
    this.instanceDir = instanceDir;
    this.phoneNumber = phoneNumber;
    this.onLog = onLog;
    this.onStatusChange = onStatusChange;
    this.engine = null;
    this.status = 'disconnected'; // disconnected | connecting | pairing | connected
    this.reconnectAttempts = 0;
    this._stopped = false;
  }

  async start() {
    this._stopped = false;
    await this._connectOnce();
  }

  async stop() {
    this._stopped = true;
    if (this.engine) await this.engine.disconnect();
    this._setStatus('disconnected');
  }

  async _connectOnce() {
    this._setStatus('connecting');
    this.engine = createWhatsAppEngine({ instanceDir: this.instanceDir, phoneNumber: this.phoneNumber });

    this.engine.on('pairing-code', (code) => {
      this._setStatus('pairing', { pairingCode: code });
    });

    this.engine.on('connection-open', async () => {
      this.reconnectAttempts = 0;
      this._setStatus('connected');
      await startCore({
        instanceId: this.instanceId,
        instanceDir: this.instanceDir,
        engine: this.engine,
        onLog: this.onLog,
      });
    });

    this.engine.on('connection-close', ({ shouldReconnect, reason }) => {
      this.onLog({ level: 'warn', instanceId: this.instanceId, message: sanitizeForLog(`اتصال قفل: ${reason}`) });
      this._setStatus('disconnected');
      if (this._stopped || !shouldReconnect) return;
      this._scheduleReconnect();
    });

    await this.engine.connect();
  }

  _scheduleReconnect() {
    this.reconnectAttempts += 1;
    const delay = Math.min(BASE_BACKOFF_MS * 2 ** (this.reconnectAttempts - 1), MAX_BACKOFF_MS);
    this.onLog({ level: 'info', instanceId: this.instanceId, message: `إعادة محاولة الاتصال بعد ${delay}ms (محاولة #${this.reconnectAttempts})` });
    setTimeout(() => {
      if (!this._stopped) this._connectOnce().catch((err) => this.onLog({ level: 'error', instanceId: this.instanceId, message: sanitizeForLog(err.message) }));
    }, delay);
  }

  _setStatus(status, extra = {}) {
    this.status = status;
    this.onStatusChange({ instanceId: this.instanceId, status, ...extra });
  }
}
