/**
 * src/core/permissions.js
 * صلاحيات على مستوى WhatsApp Core (owner/admin/group) — منفصلة تمامًا عن صلاحيات
 * الـTelegram Developer Panel (اللي موجودة في installer/auth/permissions.js).
 *
 * المستويات:
 *   - 'owner'   : رقم موجود في config.owners بتاع الـinstance
 *   - 'admin'   : أدمن في الجروب نفسه (بيتحدد وقت النداء عن طريق groupMetadata)
 *   - 'member'  : أي حد تاني
 */

export const ROLES = Object.freeze({
  OWNER: 'owner',
  ADMIN: 'admin',
  MEMBER: 'member',
});

const ROLE_RANK = { [ROLES.MEMBER]: 0, [ROLES.ADMIN]: 1, [ROLES.OWNER]: 2 };

export function isOwner(senderId, config) {
  if (!config?.owners?.length) return false;
  return config.owners.includes(normalizeJid(senderId));
}

export function isGroupAdmin(senderId, groupMetadata) {
  if (!groupMetadata?.participants) return false;
  const p = groupMetadata.participants.find(
    (participant) => normalizeJid(participant.id) === normalizeJid(senderId)
  );
  return p?.admin === 'admin' || p?.admin === 'superadmin';
}

export function resolveRole(senderId, config, groupMetadata = null) {
  if (isOwner(senderId, config)) return ROLES.OWNER;
  if (groupMetadata && isGroupAdmin(senderId, groupMetadata)) return ROLES.ADMIN;
  return ROLES.MEMBER;
}

/** true لو role الشخص >= minRole المطلوب للأمر */
export function hasPermission(role, minRole) {
  return (ROLE_RANK[role] ?? -1) >= (ROLE_RANK[minRole] ?? Infinity);
}

function normalizeJid(jid) {
  if (!jid) return '';
  // بيشيل أي @s.whatsapp.net / @g.us / device suffix (:0 مثلًا) عشان المقارنة تبقى دقيقة
  return jid.split('@')[0].split(':')[0];
}

export const _internal = { normalizeJid };
