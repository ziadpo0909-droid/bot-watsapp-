/**
 * src/core/plugin-loader.js
 * بيدور جوه src/plugins/** على ملفات .js، يعمل import ديناميكي، ويسجّلهم في
 * CommandRegistry — إلا لو الفئة (category) بتاعتهم متعطلة في config.enabledPlugins.
 *
 * كل Plugin ملف مستقل بيعمل export default { command, minRole, category, execute }.
 * ده هو نفس مبدأ V2 (ملف = أمر) عشان النقل يبقى بسيط.
 */

import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { CommandRegistry } from './command-registry.js';

export async function loadPlugins(pluginsDir, enabledPlugins = {}) {
  const registry = new CommandRegistry();
  const loaded = [];
  const skipped = [];
  const failed = [];

  const categories = await fs.readdir(pluginsDir, { withFileTypes: true });
  for (const catEntry of categories) {
    if (!catEntry.isDirectory()) continue;
    const category = catEntry.name;
    const enabled = enabledPlugins[category] !== false; // افتراضيًا مفعّل لو مش محدد
    const categoryDir = path.join(pluginsDir, category);
    const files = (await fs.readdir(categoryDir)).filter((f) => f.endsWith('.js'));

    for (const file of files) {
      const fullPath = path.join(categoryDir, file);
      if (!enabled) {
        skipped.push({ category, file, reason: 'category-disabled' });
        continue;
      }
      try {
        const mod = await import(pathToFileURL(fullPath).href);
        const def = mod.default;
        if (!def?.command || !def?.execute) {
          failed.push({ category, file, reason: 'invalid-shape' });
          continue;
        }
        registry.register({ ...def, category });
        loaded.push({ category, file, command: def.command });
      } catch (err) {
        failed.push({ category, file, reason: err.message });
      }
    }
  }

  return { registry, loaded, skipped, failed };
}
