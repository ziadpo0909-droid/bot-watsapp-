/**
 * src/core/command-registry.js
 * تسجيل واسترجاع الأوامر (Commands). الـPlugins بترجع object بالشكل ده:
 *   {
 *     command: ['ping', 'بينج'],   // أسماء/aliases بدون الـprefix
 *     minRole: 'member' | 'admin' | 'owner',
 *     category: 'owner' | 'group' | 'misc',
 *     description: '...',
 *     execute: async (ctx) => { ... }
 *   }
 * ctx بيوصل من core/index.js وفيه: { message, engine, config, groupMetadata, role, args, text }
 */

export class CommandRegistry {
  constructor() {
    this.commands = new Map(); // name -> definition
  }

  register(definition) {
    if (!definition?.command || !definition.execute) {
      throw new Error('تعريف الأمر لازم يحتوي command و execute');
    }
    const names = Array.isArray(definition.command) ? definition.command : [definition.command];
    for (const name of names) {
      if (this.commands.has(name)) {
        throw new Error(`تعارض أسماء أوامر: "${name}" مسجل قبل كده`);
      }
      this.commands.set(name, definition);
    }
    return this;
  }

  get(name) {
    return this.commands.get(name) ?? null;
  }

  has(name) {
    return this.commands.has(name);
  }

  list() {
    // بترجع Set من التعريفات الفريدة (مش الأسماء) عشان أمر باسمين متتعدش مرتين
    return [...new Set(this.commands.values())];
  }

  size() {
    return this.list().length;
  }
}

/** بتقسم نص الرسالة لـ (commandName, args) حسب الـprefix بتاع الـinstance */
export function parseCommand(text, prefix) {
  if (!text || !text.startsWith(prefix)) return null;
  const body = text.slice(prefix.length).trim();
  if (!body) return null;
  const [name, ...args] = body.split(/\s+/);
  return { name: name.toLowerCase(), args, text: args.join(' ') };
}
