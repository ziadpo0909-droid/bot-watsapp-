#!/usr/bin/env node
/**
 * src/core-runner.js
 * نقطة الدخول اللي PM2 بيشغّلها لكل instance لوحده: node src/core-runner.js <instanceId>
 *
 * ده العملية اللي بتعمل فعليًا connect() لـWhatsApp وتشغّل الـCore. الـTelegram installer
 * (عملية منفصلة تمامًا) معندهوش أي WhatsApp client هنا — بيتواصل مع العملية دي بس عن طريق:
 *   - قراءة instances/<id>/data/status.json (الحالة + Pairing Code لحظة ما يتولد)
 *   - قراءة instances/<id>/logs/core.log
 *   - PM2 API (start/stop/restart) لتشغيل/إيقاف العملية دي نفسها
 * وده هو بالظبط الشرط: "Telegram مجرد واجهة تحكم، مش WhatsApp Client تاني لنفس الـinstance".
 */

import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { EngineManager } from './core/engine-manager.js';
import { createInstanceLogger } from '../instance-manager/logger.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const instanceId = process.argv[2] || process.env.INSTANCE_ID;

if (!instanceId) {
  console.error('استخدم: node src/core-runner.js <instanceId>');
  process.exit(1);
}

const instanceDir = path.join(__dirname, '..', 'instances', instanceId);
if (!fs.existsSync(instanceDir)) {
  console.error(`instance غير موجود: ${instanceDir}`);
  process.exit(1);
}

const statusFile = path.join(instanceDir, 'data', 'status.json');
fs.mkdirSync(path.dirname(statusFile), { recursive: true });

const onLog = createInstanceLogger(instanceDir);

function writeStatus(status) {
  const payload = { ...status, updatedAt: new Date().toISOString() };
  const tmp = `${statusFile}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(payload, null, 2));
  fs.renameSync(tmp, statusFile);
}

// رقم الهاتف (لطلب Pairing Code) بييجي من ملف instances/<id>/data/pairing-request.json
// اللي الـTelegram installer بيكتبه لما المستخدم يبعت رقمه — مش argument ولا env ثابت،
// عشان نفس الـinstance يقدر يتربط بأرقام مختلفة عبر الوقت بدون إعادة تشغيل الكود.
const pairingRequestFile = path.join(instanceDir, 'data', 'pairing-request.json');
let phoneNumber = null;
if (fs.existsSync(pairingRequestFile)) {
  try {
    phoneNumber = JSON.parse(fs.readFileSync(pairingRequestFile, 'utf-8')).phoneNumber || null;
  } catch {
    phoneNumber = null;
  }
}

const manager = new EngineManager({
  instanceId,
  instanceDir,
  phoneNumber,
  onLog,
  onStatusChange: writeStatus,
});

writeStatus({ status: 'starting' });
manager.start().catch((err) => {
  onLog({ level: 'error', instanceId, message: `فشل بدء التشغيل: ${err.message}` });
  writeStatus({ status: 'error', error: err.message });
  process.exit(1);
});

process.on('SIGTERM', async () => {
  await manager.stop();
  process.exit(0);
});
process.on('SIGINT', async () => {
  await manager.stop();
  process.exit(0);
});
