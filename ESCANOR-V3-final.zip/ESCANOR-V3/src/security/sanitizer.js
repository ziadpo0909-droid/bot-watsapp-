/**
 * src/security/sanitizer.js
 * بيشيل أي حاجة حساسة من نص قبل ما يتعرض في Telegram logs أو يتكتب في ملف log.
 * بيتنادى من log-service قبل أي عرض، ومن أي مكان بيطبع نص خارجي (رسائل خطأ من مكتبات خارجية مثلاً).
 */

const PATTERNS = [
  // Google API keys (Gemini, Tenor, ...)
  { re: /AIza[0-9A-Za-z_\-]{35}/g, replacement: '[REDACTED_API_KEY]' },
  // Telegram bot tokens (123456789:AAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx)
  { re: /\d{6,12}:[A-Za-z0-9_\-]{30,}/g, replacement: '[REDACTED_TELEGRAM_TOKEN]' },
  // Generic Bearer/API key style tokens
  { re: /\b(sk|pk|key)-[A-Za-z0-9]{20,}/gi, replacement: '[REDACTED_KEY]' },
  // WhatsApp session creds file content markers (noise-level redaction: base64 blobs > 100 chars)
  { re: /[A-Za-z0-9+/]{100,}={0,2}/g, replacement: '[REDACTED_BLOB]' },
  // File paths under instances/*/session (عشان مايتسربش مسار فعلي بيدي فكرة عن هيكل السيرفر)
  { re: /instances\/[^/\s]+\/session[^\s]*/g, replacement: 'instances/<id>/session/[REDACTED_PATH]' },
];

export function sanitize(text) {
  if (typeof text !== 'string') return text;
  let out = text;
  for (const { re, replacement } of PATTERNS) {
    out = out.replace(re, replacement);
  }
  return out;
}

/** بيسنّيتز أي object عن طريق تحويله لنص، سنيتز، وإرجاعه كنص (آمن للـlogging دايمًا) */
export function sanitizeForLog(value) {
  const text = typeof value === 'string' ? value : JSON.stringify(value, null, 2);
  return sanitize(text);
}
