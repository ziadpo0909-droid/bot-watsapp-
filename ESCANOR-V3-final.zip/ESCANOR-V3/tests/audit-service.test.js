import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { AuditService } from '../instance-manager/audit-service.js';

async function makeService() {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'escanor-audit-'));
  return new AuditService(dir);
}

test('record بتحفظ العملية وبترجع entry فيه id/timestamp', async () => {
  const svc = await makeService();
  const entry = await svc.record({ developerId: '111', action: 'instance:start', instanceId: 'i1' });
  assert.ok(entry.id);
  assert.ok(entry.timestamp);
  assert.equal(entry.result, 'success');
});

test('record بتسنّيتز الـdetails لو فيها سيكريت', async () => {
  const svc = await makeService();
  await svc.record({
    developerId: '111',
    action: 'config:owner',
    details: 'AIzaSyAapx0RK6kMjIpAbdQxHtL5qS7ldrM7SGk',
  });
  const [entry] = await svc.listRecent(1);
  assert.ok(!entry.details.includes('AIzaSy'));
});

test('listRecent بترجع الأحدث الأول', async () => {
  const svc = await makeService();
  await svc.record({ developerId: '1', action: 'a' });
  await svc.record({ developerId: '1', action: 'b' });
  const recent = await svc.listRecent(2);
  assert.equal(recent[0].action, 'b');
});

test('listByInstance بترجع بس اللي خاص بالـinstance ده', async () => {
  const svc = await makeService();
  await svc.record({ developerId: '1', action: 'a', instanceId: 'i1' });
  await svc.record({ developerId: '1', action: 'b', instanceId: 'i2' });
  const forI1 = await svc.listByInstance('i1');
  assert.equal(forI1.length, 1);
  assert.equal(forI1[0].instanceId, 'i1');
});
