import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { loadConfig, saveConfig, createInitialConfig, getPublicConfig } from '../src/config/config-manager.js';

async function tmpDir() {
  return fs.mkdtemp(path.join(os.tmpdir(), 'escanor-config-'));
}

test('loadConfig بترجع defaults لو الملف مش موجود', async () => {
  const dir = await tmpDir();
  const config = await loadConfig(dir);
  assert.equal(config.prefix, '.');
  assert.deepEqual(config.owners, []);
});

test('createInitialConfig بتعمل الملف وتقدر تتقرا تاني', async () => {
  const dir = await tmpDir();
  await createInitialConfig(dir, 'instance_test', { botName: 'TestBot' });
  const config = await loadConfig(dir);
  assert.equal(config.botName, 'TestBot');
  assert.equal(config.instanceId, 'instance_test');
});

test('saveConfig بترفض prefix أطول من حرف', async () => {
  const dir = await tmpDir();
  await createInitialConfig(dir, 'i1');
  const config = await loadConfig(dir);
  await assert.rejects(() => saveConfig(dir, { ...config, prefix: 'ab' }));
});

test('saveConfig بتحفظ ويقدر يترجع بنفس القيم', async () => {
  const dir = await tmpDir();
  await createInitialConfig(dir, 'i2');
  const config = await loadConfig(dir);
  await saveConfig(dir, { ...config, prefix: '!', owners: ['201234567890'] });
  const reloaded = await loadConfig(dir);
  assert.equal(reloaded.prefix, '!');
  assert.deepEqual(reloaded.owners, ['201234567890']);
});

test('getPublicConfig بترجع object من غير ما تعدل الأصل', async () => {
  const dir = await tmpDir();
  await createInitialConfig(dir, 'i3');
  const config = await loadConfig(dir);
  const pub = getPublicConfig(config);
  assert.equal(pub.instanceId, 'i3');
});
