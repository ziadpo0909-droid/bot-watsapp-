import { test } from 'node:test';
import assert from 'node:assert/strict';
import { isDeveloper, getDeveloperIds } from '../installer/auth/permissions.js';

test('isDeveloper بترجع true للـID الموجود في DEVELOPER_IDS', () => {
  process.env.DEVELOPER_IDS = '111,222 , 333';
  assert.equal(isDeveloper(111), true);
  assert.equal(isDeveloper('222'), true);
  assert.equal(isDeveloper(333), true);
});

test('isDeveloper بترجع false للـID مش موجود', () => {
  process.env.DEVELOPER_IDS = '111,222';
  assert.equal(isDeveloper(999), false);
});

test('isDeveloper بترجع false لو DEVELOPER_IDS فاضية', () => {
  process.env.DEVELOPER_IDS = '';
  assert.equal(isDeveloper(111), false);
});

test('getDeveloperIds بتشيل المسافات وتتجاهل عناصر فاضية', () => {
  process.env.DEVELOPER_IDS = '111, ,222,';
  assert.deepEqual(getDeveloperIds(), ['111', '222']);
});
