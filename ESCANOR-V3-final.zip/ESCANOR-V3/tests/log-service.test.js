import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { readRecentLogs, formatLogsForTelegram } from '../installer/services/log-service.js';
import { createInstanceLogger } from '../instance-manager/logger.js';

async function tmpInstanceDir() {
  return fs.mkdtemp(path.join(os.tmpdir(), 'escanor-loginst-'));
}

test('readRecentLogs بترجع array فاضي لو مفيش ملف لوج', async () => {
  const dir = await tmpInstanceDir();
  const entries = await readRecentLogs(dir);
  assert.deepEqual(entries, []);
});

test('createInstanceLogger بتكتب وreadRecentLogs بتقراها متسنّتزة', async () => {
  const dir = await tmpInstanceDir();
  const onLog = createInstanceLogger(dir);
  onLog({ level: 'info', instanceId: 'i1', message: 'test message' });
  onLog({ level: 'error', instanceId: 'i1', message: 'AIzaSyAapx0RK6kMjIpAbdQxHtL5qS7ldrM7SGk leaked' });
  await new Promise((r) => setTimeout(r, 50)); // fire-and-forget append محتاج تأخيرة بسيطة

  const entries = await readRecentLogs(dir, { limit: 10 });
  assert.equal(entries.length, 2);
  assert.ok(!entries[1].message.includes('AIzaSy'));
});

test('formatLogsForTelegram بترجع نص مقروء وبتحترم حد الطول', () => {
  const entries = Array.from({ length: 5 }, (_, i) => ({ ts: '2026-01-01', level: 'info', message: `msg${i}` }));
  const text = formatLogsForTelegram(entries);
  assert.ok(text.includes('msg0'));
  assert.ok(text.length <= 3500);
});

test('formatLogsForTelegram بترجع رسالة واضحة لو مفيش logs', () => {
  assert.equal(formatLogsForTelegram([]), 'مفيش logs لسه.');
});
