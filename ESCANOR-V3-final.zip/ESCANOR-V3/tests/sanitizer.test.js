import { test } from 'node:test';
import assert from 'node:assert/strict';
import { sanitize, sanitizeForLog } from '../src/security/sanitizer.js';

test('بتشيل Google API keys (AIza...)', () => {
  const out = sanitize('key=AIzaSyAapx0RK6kMjIpAbdQxHtL5qS7ldrM7SGk here');
  assert.ok(!out.includes('AIzaSy'));
  assert.ok(out.includes('[REDACTED_API_KEY]'));
});

test('بتشيل Telegram bot tokens', () => {
  const out = sanitize('token: 123456789:AAHdqTcvCH1vGWJxfSeofSAs0K5PALDsaw5');
  assert.ok(!out.includes('AAHdqTcvCH1vGWJxfSeofSAs0K5PALDsaw5'));
  assert.ok(out.includes('[REDACTED_TELEGRAM_TOKEN]'));
});

test('بتشيل مسارات session', () => {
  const out = sanitize('failed to read instances/instance_ab12/session/creds.json');
  assert.ok(!out.includes('instance_ab12'));
});

test('نص عادي من غير سيكريتس بيرجع زي ما هو', () => {
  const out = sanitize('أمر: ping من 201234567890');
  assert.equal(out, 'أمر: ping من 201234567890');
});

test('sanitizeForLog بتشتغل مع objects كمان', () => {
  const out = sanitizeForLog({ error: 'AIzaSyAapx0RK6kMjIpAbdQxHtL5qS7ldrM7SGk' });
  assert.ok(!out.includes('AIzaSy'));
});
