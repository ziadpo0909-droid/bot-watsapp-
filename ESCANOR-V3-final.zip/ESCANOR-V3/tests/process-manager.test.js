import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ProcessManager } from '../instance-manager/process-manager.js';

/** Mock بسيط بيقلد شكل pm2 API (connect/start/stop/restart/delete/describe/disconnect) */
function makeMockPm2({ shouldFailStart = false } = {}) {
  const calls = [];
  return {
    calls,
    connect(cb) {
      calls.push('connect');
      cb(null);
    },
    disconnect() {
      calls.push('disconnect');
    },
    start(opts, cb) {
      calls.push(['start', opts]);
      if (shouldFailStart) return cb(new Error('pm2 start failed'));
      cb(null, { name: opts.name });
    },
    stop(name, cb) {
      calls.push(['stop', name]);
      cb(null, { name });
    },
    restart(name, cb) {
      calls.push(['restart', name]);
      cb(null, { name });
    },
    delete(name, cb) {
      calls.push(['delete', name]);
      cb(null, { name });
    },
    describe(name, cb) {
      calls.push(['describe', name]);
      cb(null, [{ name, pm2_env: { status: 'online' } }]);
    },
  };
}

test('run(start) بتنادي pm2.start بالاسم الصح وتقفل الاتصال', async () => {
  const pm2 = makeMockPm2();
  const pmMgr = new ProcessManager({ pm2Client: pm2, scriptPath: '/x/core-runner.js' });
  await pmMgr.run('start', 'instance_abc');
  const startCall = pm2.calls.find((c) => Array.isArray(c) && c[0] === 'start');
  assert.equal(startCall[1].name, 'escanor_instance_abc');
  assert.deepEqual(startCall[1].args, ['instance_abc']);
  assert.ok(pm2.calls.includes('connect'));
  assert.ok(pm2.calls.includes('disconnect'));
});

test('run بترفض action مش موجودة في الـallowlist', async () => {
  const pm2 = makeMockPm2();
  const pmMgr = new ProcessManager({ pm2Client: pm2, scriptPath: '/x' });
  await assert.rejects(() => pmMgr.run('exec', 'instance_abc'), /غير مسموح/);
});

test('run بترفض من غير instanceId', async () => {
  const pm2 = makeMockPm2();
  const pmMgr = new ProcessManager({ pm2Client: pm2, scriptPath: '/x' });
  await assert.rejects(() => pmMgr.run('start', undefined));
});

test('run(stop) بتقفل الاتصال حتى لو فشلت العملية', async () => {
  const pm2 = makeMockPm2({ shouldFailStart: true });
  const pmMgr = new ProcessManager({ pm2Client: pm2, scriptPath: '/x' });
  await assert.rejects(() => pmMgr.run('start', 'instance_x'));
  assert.ok(pm2.calls.includes('disconnect'));
});

test('constructor بيرفض من غير pm2Client (منع الاعتماد الضمني على exec حر)', () => {
  assert.throws(() => new ProcessManager({ scriptPath: '/x' }));
});
