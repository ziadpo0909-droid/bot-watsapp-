import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { InstanceService } from '../instance-manager/instance-service.js';

async function makeService() {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'escanor-instances-'));
  const dbDir = await fs.mkdtemp(path.join(os.tmpdir(), 'escanor-db-'));
  return new InstanceService({ instancesRoot: root, dbDir });
}

test('create بتعمل instance جديد بفولدرات session/config/data/logs', async () => {
  const svc = await makeService();
  const inst = await svc.create({ telegramOwnerId: '111' });
  assert.ok(inst.instanceId.startsWith('instance_'));
  for (const sub of ['session', 'config', 'data', 'logs']) {
    const stat = await fs.stat(path.join(svc.instanceDir(inst.instanceId), sub));
    assert.ok(stat.isDirectory());
  }
});

test('list بترجع بس instances بتاعة owner معين', async () => {
  const svc = await makeService();
  await svc.create({ telegramOwnerId: '111' });
  await svc.create({ telegramOwnerId: '222' });
  const forOwner1 = await svc.list('111');
  assert.equal(forOwner1.length, 1);
  const all = await svc.list();
  assert.equal(all.length, 2);
});

test('delete بتشيل السجل والفولدر مع بعض', async () => {
  const svc = await makeService();
  const inst = await svc.create({ telegramOwnerId: '111' });
  const removed = await svc.delete(inst.instanceId);
  assert.equal(removed, true);
  assert.equal(await svc.get(inst.instanceId), null);
  await assert.rejects(() => fs.stat(svc.instanceDir(inst.instanceId)));
});

test('assertOwnership بترفض لو مش صاحب الـinstance ومش developer', async () => {
  const svc = await makeService();
  const inst = await svc.create({ telegramOwnerId: '111' });
  await assert.rejects(() => svc.assertOwnership(inst.instanceId, '999', false));
});

test('assertOwnership بتسمح للـdeveloper حتى لو مش صاحب الـinstance', async () => {
  const svc = await makeService();
  const inst = await svc.create({ telegramOwnerId: '111' });
  const record = await svc.assertOwnership(inst.instanceId, '999', true);
  assert.equal(record.instanceId, inst.instanceId);
});

test('create متزامن لمرتين متختلطش الـIDs (race condition check)', async () => {
  const svc = await makeService();
  const [a, b] = await Promise.all([
    svc.create({ telegramOwnerId: '1' }),
    svc.create({ telegramOwnerId: '2' }),
  ]);
  assert.notEqual(a.instanceId, b.instanceId);
  const all = await svc.list();
  assert.equal(all.length, 2);
});
