import { test } from 'node:test';
import assert from 'node:assert/strict';
import { CommandRegistry, parseCommand } from '../src/core/command-registry.js';

test('parseCommand بترجع null لو مفيش prefix', () => {
  assert.equal(parseCommand('ping', '.'), null);
});

test('parseCommand بتفصل الاسم عن الـargs', () => {
  const parsed = parseCommand('.kick @201111111111', '.');
  assert.equal(parsed.name, 'kick');
  assert.deepEqual(parsed.args, ['@201111111111']);
});

test('CommandRegistry: تسجيل واسترجاع أمر بأكتر من اسم', () => {
  const registry = new CommandRegistry();
  registry.register({ command: ['ping', 'بينج'], execute: async () => {} });
  assert.ok(registry.has('ping'));
  assert.ok(registry.has('بينج'));
  assert.equal(registry.get('ping'), registry.get('بينج'));
});

test('CommandRegistry: بترمي error لو نفس الاسم اتسجل مرتين', () => {
  const registry = new CommandRegistry();
  registry.register({ command: ['ping'], execute: async () => {} });
  assert.throws(() => registry.register({ command: ['ping'], execute: async () => {} }));
});

test('CommandRegistry.list() بترجع تعريفات فريدة مش مكررة', () => {
  const registry = new CommandRegistry();
  registry.register({ command: ['help', 'مساعدة'], execute: async () => {} });
  assert.equal(registry.list().length, 1);
});
