import { test } from 'node:test';
import assert from 'node:assert/strict';
import { resolveRole, hasPermission, ROLES, isOwner, isGroupAdmin } from '../src/core/permissions.js';

const config = { owners: ['201111111111'] };
const groupMetadata = {
  participants: [
    { id: '201111111111@s.whatsapp.net', admin: null },
    { id: '202222222222@s.whatsapp.net', admin: 'admin' },
    { id: '203333333333@s.whatsapp.net', admin: null },
  ],
};

test('صاحب رقم في owners بيبقى owner حتى لو مش أدمن في الجروب', () => {
  assert.equal(resolveRole('201111111111@s.whatsapp.net', config, groupMetadata), ROLES.OWNER);
});

test('أدمن في الجروب بيبقى admin لو مش owner', () => {
  assert.equal(resolveRole('202222222222@s.whatsapp.net', config, groupMetadata), ROLES.ADMIN);
});

test('عضو عادي بيبقى member', () => {
  assert.equal(resolveRole('203333333333@s.whatsapp.net', config, groupMetadata), ROLES.MEMBER);
});

test('عضو مش في الجروب أصلًا برضو member (مش بيرمي error)', () => {
  assert.equal(resolveRole('209999999999@s.whatsapp.net', config, groupMetadata), ROLES.MEMBER);
});

test('hasPermission: owner يقدر ينفذ أوامر admin وmember', () => {
  assert.equal(hasPermission(ROLES.OWNER, ROLES.ADMIN), true);
  assert.equal(hasPermission(ROLES.OWNER, ROLES.MEMBER), true);
});

test('hasPermission: member مايقدرش ينفذ أوامر admin', () => {
  assert.equal(hasPermission(ROLES.MEMBER, ROLES.ADMIN), false);
});

test('isOwner بتتجاهل الـdevice suffix (:0) في الـJID', () => {
  assert.equal(isOwner('201111111111:0@s.whatsapp.net', config), true);
});

test('isGroupAdmin بترجع false لو مفيش groupMetadata', () => {
  assert.equal(isGroupAdmin('202222222222@s.whatsapp.net', null), false);
});
