import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { JsonTable } from '../instance-manager/json-db.js';

async function makeTable() {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'escanor-jsondb-'));
  return new JsonTable(dir, 'test_table');
}

test('insert/readAll', async () => {
  const t = await makeTable();
  await t.insert({ id: 1, name: 'a' });
  const rows = await t.readAll();
  assert.equal(rows.length, 1);
});

test('update بتغيّر الصف الصح بس', async () => {
  const t = await makeTable();
  await t.insert({ id: 1, status: 'x' });
  await t.insert({ id: 2, status: 'x' });
  await t.update((r) => r.id === 1, () => ({ status: 'y' }));
  const rows = await t.readAll();
  assert.equal(rows.find((r) => r.id === 1).status, 'y');
  assert.equal(rows.find((r) => r.id === 2).status, 'x');
});

test('remove بترجع عدد الصفوف المشالة', async () => {
  const t = await makeTable();
  await t.insert({ id: 1 });
  await t.insert({ id: 2 });
  const removed = await t.remove((r) => r.id === 1);
  assert.equal(removed, 1);
  assert.equal((await t.readAll()).length, 1);
});

test('كتابات متزامنة كتير مايضيعش أي صف (lock بيشتغل صح)', async () => {
  const t = await makeTable();
  await Promise.all(Array.from({ length: 20 }, (_, i) => t.insert({ id: i })));
  const rows = await t.readAll();
  assert.equal(rows.length, 20);
});

test('findOne بترجع null لو مفيش تطابق', async () => {
  const t = await makeTable();
  const found = await t.findOne((r) => r.id === 999);
  assert.equal(found, null);
});
