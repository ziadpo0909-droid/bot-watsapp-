import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { loadPlugins } from '../src/core/plugin-loader.js';

async function makePluginsDir(structure) {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'escanor-plugins-'));
  for (const [category, files] of Object.entries(structure)) {
    const catDir = path.join(dir, category);
    await fs.mkdir(catDir, { recursive: true });
    for (const [file, content] of Object.entries(files)) {
      await fs.writeFile(path.join(catDir, file), content, 'utf-8');
    }
  }
  return dir;
}

test('loadPlugins بتحمّل plugin صحيح وتسجّله', async () => {
  const dir = await makePluginsDir({
    misc: {
      'ping.js': `export default { command: ['ping'], execute: async () => {} };`,
    },
  });
  const { registry, loaded, failed } = await loadPlugins(dir, {});
  assert.equal(loaded.length, 1);
  assert.equal(failed.length, 0);
  assert.ok(registry.has('ping'));
});

test('loadPlugins بتتجاهل category متعطلة', async () => {
  const dir = await makePluginsDir({
    owner: { 'x.js': `export default { command: ['x'], execute: async () => {} };` },
  });
  const { loaded, skipped } = await loadPlugins(dir, { owner: false });
  assert.equal(loaded.length, 0);
  assert.equal(skipped.length, 1);
});

test('loadPlugins بتسجّل failed لو الـplugin ملوش command أو execute', async () => {
  const dir = await makePluginsDir({
    misc: { 'bad.js': `export default { notCommand: true };` },
  });
  const { failed, loaded } = await loadPlugins(dir, {});
  assert.equal(loaded.length, 0);
  assert.equal(failed.length, 1);
  assert.equal(failed[0].reason, 'invalid-shape');
});

test('loadPlugins بتسجّل failed لو فيه syntax error في الملف', async () => {
  const dir = await makePluginsDir({
    misc: { 'broken.js': `export default { command: ['x'` }, // syntax error مقصود
  });
  const { failed } = await loadPlugins(dir, {});
  assert.equal(failed.length, 1);
});
