/**
 * scripts/manual-whatsapp-check.js
 *
 * سكريبت اختبار يدوي لـ Phase 2. لازم يتشغل على الـVPS (مش هنا)، لأنه محتاج
 * اتصال إنترنت حقيقي + رقم واتساب حقيقي عشان يعمل Pairing.
 *
 * تشغيل:
 *   node scripts/manual-whatsapp-check.js 20xxxxxxxxxx
 *   (رقم الواتساب بصيغة دولية بدون + أو مسافات)
 *
 * السكريبت بيغطي البنود دي بالترتيب:
 *   1. Connection
 *   2. Pairing Code
 *   3. Session persistence (شغّله تاني بعد أول اتصال ناجح، من غير ما تمسح instances/test-phase2/session)
 *   4. استقبال رسالة  (ابعت أي رسالة من موبايلك لنفسك أو لجروب فيه الرقم ده)
 *   5. إرسال رسالة    (بيرد تلقائي "✅ Echo: <نصك>" على أي رسالة تستقبلها)
 *   6. Group metadata + groupParticipantsUpdate (لو الرقم عضو في جروب، دخّل/شيل حد تجريبيًا)
 *   7. Disconnect/Reconnect (Ctrl+C يوقف بأمان عن طريق logout يدوي لو عايز تختبر إعادة الـpairing،
 *      أو SIGTERM عادي لإعادة تشغيل بنفس الـsession)
 */

import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createWhatsAppEngine } from '../src/whatsapp/index.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const phoneNumber = process.argv[2];

if (!phoneNumber) {
  console.error('❌ استخدم: node scripts/manual-whatsapp-check.js <رقم الواتساب بصيغة دولية>');
  process.exit(1);
}

const instanceDir = path.join(__dirname, '..', 'instances', 'test-phase2');

console.log('=== ESCANOR V3 — Phase 2 Adapter Test ===');
console.log(`instanceDir: ${instanceDir}`);
console.log(`phoneNumber: ${phoneNumber}`);
console.log('');

const engine = createWhatsAppEngine({ instanceDir, phoneNumber });

engine.on('pairing-code', (code) => {
  console.log(`\n🔑 Pairing Code: ${code}`);
  console.log('   افتح واتساب على موبايلك → الأجهزة المرتبطة → ربط جهاز → أدخل الكود ده.\n');
});

engine.on('qr', (qr) => {
  console.log('\n📷 QR string اتولد (متوقع نستخدم Pairing Code مش QR، بس هنا لو حصل fallback):');
  console.log(qr, '\n');
});

engine.on('connection-open', () => {
  console.log('✅ [1] Connection: نجح الاتصال.');
  console.log('✅ [2] Pairing: نجح (لو دي أول مرة) أو [3] Session persistence: نجح (لو ده تشغيل تاني بنفس الـsession).');
  console.log('👉 دلوقتي ابعت أي رسالة واتساب للرقم ده (أو لجروب هو عضو فيه) عشان نختبر الاستقبال والرد.');
});

engine.on('message', async (msg) => {
  if (msg.fromMe) return;
  console.log('✅ [4] استقبال رسالة نجح:', {
    from: msg.senderId,
    chat: msg.chatId,
    text: msg.textBody,
  });

  if (msg.textBody) {
    try {
      await engine.sendMessage(msg.chatId, { text: `✅ Echo: ${msg.textBody}` });
      console.log('✅ [5] إرسال رسالة (رد) نجح.');
    } catch (err) {
      console.error('❌ [5] فشل الإرسال:', err.message);
    }
  }
});

engine.on('group-participants-update', async ({ groupId, participants, action }) => {
  console.log('✅ [6] groupParticipantsUpdate اشتغل:', { groupId, participants, action });
  try {
    const meta = await engine.getGroupMetadata(groupId);
    console.log('✅ [6] Group metadata اتجابت:', {
      subject: meta.subject,
      participantsCount: meta.participants?.length,
    });
  } catch (err) {
    console.error('❌ [6] فشل جلب Group metadata:', err.message);
  }
});

engine.on('connection-close', ({ shouldReconnect, reason }) => {
  console.log(`⚠️ [7] الاتصال قفل. reason=${reason} shouldReconnect=${shouldReconnect}`);
  if (shouldReconnect) {
    console.log('   هيعيد المحاولة تلقائيًا...');
    engine.connect().catch((err) => console.error('❌ فشل إعادة الاتصال:', err.message));
  } else {
    console.log('   مفيش إعادة اتصال (على الأغلب Logout). شغّل السكريبت تاني لو عايز pairing جديد.');
    process.exit(0);
  }
});

process.on('SIGINT', async () => {
  console.log('\n⏹  استلمت Ctrl+C — بنقفل الاتصال بأمان (SIGTERM-style, مش logout) عشان الـSession تفضل محفوظة...');
  if (engine.sock) {
    engine.sock.end(undefined);
  }
  console.log('   شغّل السكريبت تاني دلوقتي عشان تختبر [3] Session persistence و [7] Reconnect.');
  process.exit(0);
});

engine.connect().catch((err) => {
  console.error('❌ [1] فشل الاتصال الأولي:', err);
  process.exit(1);
});
