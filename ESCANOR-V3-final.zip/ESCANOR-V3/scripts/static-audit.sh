#!/usr/bin/env bash
set -e
echo "=== Static Audit: exec/eval/Function/child_process (خارج node_modules) ==="
grep -rnE "eval\(|new Function\(|execSync\(|child_process" --include="*.js" src installer instance-manager scripts 2>/dev/null | grep -v "process-manager.js" || echo "لا يوجد."
echo ""
echo "=== Static Audit: مفاتيح API صريحة (AIza...) ==="
grep -rnE "AIza[0-9A-Za-z_-]{35}" --include="*.js" . 2>/dev/null | grep -v node_modules || echo "لا يوجد."
echo ""
echo "=== Static Audit: dependency ranges (لازم تكون exact، بدون ^ / ~) ==="
grep -E '"\^|"~' package.json && echo "⚠️ فيه ranges!" || echo "كله exact ✅"
