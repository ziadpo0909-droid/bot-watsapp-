/**
 * installer/services/log-service.js
 * بيقرا آخر N سطر من instances/<id>/logs/core.log لعرضهم على Telegram.
 * اللوجز نفسها متسنّتزة أصلًا وقت الكتابة (instance-manager/logger.js)، لكن بنعمل
 * تمرير تاني هنا كطبقة حماية إضافية (defense in depth) قبل أي عرض خارجي.
 */

import fs from 'node:fs/promises';
import path from 'node:path';
import { sanitizeForLog } from '../../src/security/sanitizer.js';

export async function readRecentLogs(instanceDir, { limit = 30, levelFilter = null } = {}) {
  const file = path.join(instanceDir, 'logs', 'core.log');
  let raw;
  try {
    raw = await fs.readFile(file, 'utf-8');
  } catch (err) {
    if (err.code === 'ENOENT') return [];
    throw err;
  }
  const lines = raw.trim().split('\n').filter(Boolean);
  const entries = lines
    .map((line) => {
      try {
        return JSON.parse(line);
      } catch {
        return null;
      }
    })
    .filter(Boolean)
    .filter((e) => !levelFilter || e.level === levelFilter);

  return entries.slice(-limit).map((e) => ({ ...e, message: sanitizeForLog(e.message) }));
}

export function formatLogsForTelegram(entries) {
  if (!entries.length) return 'مفيش logs لسه.';
  return entries
    .map((e) => `[${e.ts}] ${e.level.toUpperCase()}: ${e.message}`)
    .join('\n')
    .slice(0, 3500); // حد أقصى لطول رسالة Telegram
}
