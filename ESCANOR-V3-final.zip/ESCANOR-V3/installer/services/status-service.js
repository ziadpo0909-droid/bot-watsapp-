/**
 * installer/services/status-service.js
 * القراءة/الكتابة بتاعة الـTelegram installer لملفات الحالة بتاعة كل instance.
 * ده الملف الوحيد اللي الـinstaller بيتواصل بيه مع عملية core-runner (عن طريق ملفات، مش استدعاء مباشر).
 */

import fs from 'node:fs/promises';
import path from 'node:path';

export async function readStatus(instanceDir) {
  const file = path.join(instanceDir, 'data', 'status.json');
  try {
    return JSON.parse(await fs.readFile(file, 'utf-8'));
  } catch (err) {
    if (err.code === 'ENOENT') return { status: 'never-started' };
    throw err;
  }
}

/** بيتكتب لما المستخدم يبعت رقمه من Telegram — core-runner بيقراه لما يبدأ ويطلب Pairing Code بيه */
export async function requestPairing(instanceDir, phoneNumber) {
  const file = path.join(instanceDir, 'data', 'pairing-request.json');
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, JSON.stringify({ phoneNumber, requestedAt: new Date().toISOString() }, null, 2));
}

export async function clearPairingRequest(instanceDir) {
  const file = path.join(instanceDir, 'data', 'pairing-request.json');
  await fs.rm(file, { force: true });
}
