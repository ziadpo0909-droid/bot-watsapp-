export function userMenuKeyboard() {
  return {
    reply_markup: {
      inline_keyboard: [
        [{ text: '➕ ربط رقم واتساب جديد', callback_data: 'user:link' }],
        [{ text: '📶 حالة الاتصال', callback_data: 'user:status' }],
        [{ text: '🔌 فصل الاتصال', callback_data: 'user:unlink' }],
      ],
    },
  };
}
