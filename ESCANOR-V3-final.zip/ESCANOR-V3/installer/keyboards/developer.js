export function developerMenuKeyboard() {
  return {
    reply_markup: {
      inline_keyboard: [
        [{ text: '📦 الـInstances', callback_data: 'dev:instances' }],
        [{ text: '🖥️ السيرفر (PM2)', callback_data: 'dev:server' }],
        [{ text: '🧩 الـPlugins', callback_data: 'dev:plugins' }],
        [{ text: '⚙️ الإعدادات', callback_data: 'dev:settings' }],
        [{ text: '📜 اللوجز', callback_data: 'dev:logs' }],
        [{ text: '🛡️ الأمان', callback_data: 'dev:security' }],
      ],
    },
  };
}

export function instanceActionsKeyboard(instanceId) {
  return {
    reply_markup: {
      inline_keyboard: [
        [
          { text: '▶️ Start', callback_data: `dev:instance:start:${instanceId}` },
          { text: '⏹ Stop', callback_data: `dev:instance:stop:${instanceId}` },
          { text: '🔁 Restart', callback_data: `dev:instance:restart:${instanceId}` },
        ],
        [{ text: '🗑 حذف', callback_data: `dev:instance:delete:${instanceId}` }],
      ],
    },
  };
}
