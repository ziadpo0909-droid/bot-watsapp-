#!/usr/bin/env node
/**
 * installer/bot.js
 * نقطة دخول الـTelegram Control Layer. عملية Node منفصلة تمامًا عن أي WhatsApp
 * instance — بتتكلم مع instances عن طريق ProcessManager (PM2) وملفات الحالة/اللوج بس.
 *
 * تشغيل production: PM2 كمان (process لوحده اسمه escanor_installer).
 */

import 'dotenv/config';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Telegraf } from 'telegraf';

import { InstanceService } from '../instance-manager/instance-service.js';
import { ProcessManager } from '../instance-manager/process-manager.js';
import { AuditService } from '../instance-manager/audit-service.js';

import { registerStartHandler } from './handlers/start.js';
import { registerUserHandlers } from './handlers/user.js';
import { registerDeveloperHandlers } from './handlers/developer.js';
import { registerInstanceHandlers } from './handlers/instances.js';
import { registerSettingsHandlers } from './handlers/settings.js';
import { registerPluginHandlers } from './handlers/plugins.js';
import { registerServerHandlers } from './handlers/server.js';
import { registerLogHandlers } from './handlers/logs.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const token = process.env.TELEGRAM_BOT_TOKEN;
if (!token) {
  console.error('❌ TELEGRAM_BOT_TOKEN مش موجود في .env');
  process.exit(1);
}

const instancesRoot = path.join(__dirname, '..', 'instances');
const dbDir = path.join(__dirname, '..', 'data');

const instanceService = new InstanceService({ instancesRoot, dbDir });
const auditService = new AuditService(dbDir);

// pm2 بييتحمل هنا بس (lazy) — عشان الملف ده يفضل قابل للـimport في بيئة الاختبار
// من غير ما محتاج pm2 مثبتة فعليًا (process-manager.js بياخد الـclient بالـDI).
const pm2 = (await import('pm2')).default;
const processManager = new ProcessManager({
  pm2Client: pm2,
  scriptPath: path.join(__dirname, '..', 'src', 'core-runner.js'),
});

const bot = new Telegraf(token);
const deps = { instanceService, processManager, auditService };

registerStartHandler(bot);
registerUserHandlers(bot, deps);
registerDeveloperHandlers(bot, deps);
registerInstanceHandlers(bot, deps);
registerSettingsHandlers(bot, deps);
registerPluginHandlers(bot, deps);
registerServerHandlers(bot, deps);
registerLogHandlers(bot, deps);

bot.catch((err, ctx) => {
  console.error(`خطأ في تحديث Telegram (${ctx.updateType}):`, err.message);
});

bot.launch();
console.log('✅ ESCANOR V3 Telegram installer شغال.');

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
