/**
 * installer/auth/permissions.js
 * صلاحيات Telegram (منفصلة عن src/core/permissions.js اللي للـWhatsApp).
 * DEVELOPER_IDS بييجي من .env، لازم يبقى IDs أرقام Telegram حقيقية مفصولة بفاصلة.
 */

export function getDeveloperIds() {
  const raw = process.env.DEVELOPER_IDS || '';
  return raw
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
}

export function isDeveloper(telegramId) {
  if (!telegramId) return false;
  return getDeveloperIds().includes(String(telegramId));
}

/** Middleware بتاع telegraf: بيوقف أي Update من مستخدم مش Developer لو هينادي developerOnly */
export function developerOnly() {
  return (ctx, next) => {
    const id = ctx.from?.id;
    if (!isDeveloper(id)) {
      return ctx.reply('❌ الأمر ده للـDeveloper بس.');
    }
    return next();
  };
}
