import { developerOnly } from '../auth/permissions.js';

export function registerServerHandlers(bot, { instanceService, processManager, auditService }) {
  bot.action('dev:server', developerOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const instances = await instanceService.list();
    const lines = await Promise.all(
      instances.map(async (i) => {
        try {
          const desc = await processManager.run('status', i.instanceId);
          const proc = Array.isArray(desc) ? desc[0] : desc;
          const status = proc?.pm2_env?.status || 'unknown';
          return `${i.label}: ${status}`;
        } catch {
          return `${i.label}: not-running`;
        }
      })
    );
    await ctx.reply(`🖥️ حالة الـPM2 processes:\n\n${lines.join('\n') || '(مفيش instances)'}`);
  });

  bot.command('restart_all', developerOnly(), async (ctx) => {
    const instances = await instanceService.list();
    for (const i of instances) {
      await processManager.run('restart', i.instanceId).catch(() => {});
    }
    await auditService.record({ developerId: String(ctx.from.id), action: 'server:restart_all', result: 'success' });
    await ctx.reply(`🔁 اتعمل Restart لـ ${instances.length} instance.`);
  });
}
