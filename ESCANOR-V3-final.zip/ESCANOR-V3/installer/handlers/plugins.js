import { developerOnly } from '../auth/permissions.js';
import { loadConfig, saveConfig } from '../../src/config/config-manager.js';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PLUGINS_DIR = path.join(__dirname, '..', '..', 'src', 'plugins');

export function registerPluginHandlers(bot, { instanceService, auditService }) {
  bot.action('dev:plugins', developerOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const instances = await instanceService.list();
    if (!instances.length) return ctx.reply('مفيش instances لسه.');
    const buttons = instances.map((i) => [{ text: i.label, callback_data: `dev:plugins:show:${i.instanceId}` }]);
    await ctx.reply('اختار الـinstance:', { reply_markup: { inline_keyboard: buttons } });
  });

  bot.action(/dev:plugins:show:(.+)/, developerOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const instanceId = ctx.match[1];
    const categories = (await fs.readdir(PLUGINS_DIR, { withFileTypes: true }))
      .filter((e) => e.isDirectory())
      .map((e) => e.name);
    const config = await loadConfig(instanceService.instanceDir(instanceId));

    const buttons = categories.map((cat) => {
      const enabled = config.enabledPlugins[cat] !== false;
      return [{ text: `${enabled ? '🟢' : '🔴'} ${cat}`, callback_data: `dev:plugins:toggle:${instanceId}:${cat}` }];
    });
    await ctx.reply(`🧩 Plugins — ${instanceId}:`, { reply_markup: { inline_keyboard: buttons } });
  });

  bot.action(/dev:plugins:toggle:([^:]+):(.+)/, developerOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const [, instanceId, category] = ctx.match;
    const instanceDir = instanceService.instanceDir(instanceId);
    const config = await loadConfig(instanceDir);
    const current = config.enabledPlugins[category] !== false;
    const updated = { ...config, enabledPlugins: { ...config.enabledPlugins, [category]: !current } };
    await saveConfig(instanceDir, updated);
    await auditService.record({
      developerId: String(ctx.from.id),
      action: `plugin:toggle:${category}`,
      instanceId,
      result: 'success',
      details: `${!current}`,
    });
    await ctx.reply(`${!current ? '🟢 اتفعّل' : '🔴 اتعطّل'}: ${category} (محتاج Restart للـinstance)`);
  });
}
