import { developerOnly } from '../auth/permissions.js';
import { instanceActionsKeyboard, developerMenuKeyboard } from '../keyboards/developer.js';
import { readStatus, requestPairing } from '../services/status-service.js';

const pendingLabel = new Map();
const pendingPairingPhone = new Map(); // telegramId -> instanceId

export function registerInstanceHandlers(bot, { instanceService, processManager, auditService }) {
  bot.action('dev:instances', developerOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const instances = await instanceService.list();
    if (!instances.length) {
      return ctx.reply('مفيش Instances لسه. ابعت /new_instance عشان تعمل واحد.');
    }
    for (const inst of instances) {
      const status = await readStatus(instanceService.instanceDir(inst.instanceId));
      await ctx.reply(`📦 ${inst.label} (${inst.instanceId})\nالحالة: ${status.status}`, instanceActionsKeyboard(inst.instanceId));
    }
  });

  bot.command('new_instance', developerOnly(), async (ctx) => {
    pendingLabel.set(ctx.from.id, true);
    await ctx.reply('اكتب اسم/label للـinstance الجديد:');
  });

  bot.on('text', async (ctx, next) => {
    if (pendingLabel.has(ctx.from.id)) {
      pendingLabel.delete(ctx.from.id);
      const label = ctx.message.text.trim();
      const inst = await instanceService.create({ telegramOwnerId: String(ctx.from.id), label });
      await auditService.record({ developerId: String(ctx.from.id), action: 'instance:create', instanceId: inst.instanceId });
      await ctx.reply(`✅ اتعمل: ${inst.instanceId}`, developerMenuKeyboard());
      return;
    }
    if (pendingPairingPhone.has(ctx.from.id)) {
      const instanceId = pendingPairingPhone.get(ctx.from.id);
      pendingPairingPhone.delete(ctx.from.id);
      const phoneNumber = ctx.message.text.replace(/\D/g, '');
      await requestPairing(instanceService.instanceDir(instanceId), phoneNumber);
      await processManager.run('restart', instanceId).catch(() => processManager.run('start', instanceId));
      await ctx.reply('⏳ جاري توليد Pairing Code... تابع من "📦 الـInstances".');
      return;
    }
    return next();
  });

  bot.action(/dev:instance:(start|stop|restart|delete):(.+)/, developerOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const [, action, instanceId] = ctx.match;
    const developerId = String(ctx.from.id);

    try {
      if (action === 'delete') {
        await processManager.run('stop', instanceId).catch(() => {});
        await processManager.run('delete', instanceId).catch(() => {});
        await instanceService.delete(instanceId);
      } else {
        await processManager.run(action, instanceId);
        await instanceService.setStatus(instanceId, action === 'stop' ? 'disconnected' : 'starting');
      }
      await auditService.record({ developerId, action: `instance:${action}`, instanceId, result: 'success' });
      await ctx.reply(`✅ ${action} تم لـ ${instanceId}`);
    } catch (err) {
      await auditService.record({ developerId, action: `instance:${action}`, instanceId, result: 'failed', details: err.message });
      await ctx.reply(`❌ فشل: ${err.message}`);
    }
  });
}
