/**
 * installer/handlers/user.js
 * لوحة المستخدم العادي: ربط رقم واحد بس (مبسطة عمدًا حسب السبك — Multi-instance
 * الكامل للـDeveloper فقط عن طريق لوحة الـDeveloper).
 */

import { userMenuKeyboard } from '../keyboards/user.js';
import { readStatus, requestPairing } from '../services/status-service.js';

const pendingPhoneRequests = new Map(); // telegramId -> true (بستنى منه يبعت رقمه كنص عادي)

export function registerUserHandlers(bot, { instanceService, processManager, auditService }) {
  bot.action('user:link', async (ctx) => {
    await ctx.answerCbQuery();
    pendingPhoneRequests.set(ctx.from.id, true);
    await ctx.reply('📱 ابعت رقم الواتساب بصيغة دولية (من غير + أو مسافات)، مثال: 201234567890');
  });

  bot.action('user:status', async (ctx) => {
    await ctx.answerCbQuery();
    const instances = await instanceService.list(String(ctx.from.id));
    if (!instances.length) return ctx.reply('مفيش رقم متربط لسه.', userMenuKeyboard());
    for (const inst of instances) {
      const status = await readStatus(instanceService.instanceDir(inst.instanceId));
      await ctx.reply(`📶 ${inst.label}: ${describeStatus(status)}`);
    }
  });

  bot.action('user:unlink', async (ctx) => {
    await ctx.answerCbQuery();
    const instances = await instanceService.list(String(ctx.from.id));
    if (!instances.length) return ctx.reply('مفيش رقم متربط أصلًا.');
    for (const inst of instances) {
      await processManager.run('stop', inst.instanceId).catch(() => {});
      await instanceService.setStatus(inst.instanceId, 'disconnected');
    }
    await auditService.record({ developerId: String(ctx.from.id), action: 'user:unlink', result: 'success' });
    await ctx.reply('🔌 تم فصل الاتصال.');
  });

  bot.on('text', async (ctx, next) => {
    if (!pendingPhoneRequests.has(ctx.from.id)) return next();
    pendingPhoneRequests.delete(ctx.from.id);

    const phoneNumber = ctx.message.text.replace(/\D/g, '');
    if (phoneNumber.length < 8) {
      return ctx.reply('❌ الرقم مش صحيح. جرب تاني من القائمة.', userMenuKeyboard());
    }

    let instance = (await instanceService.list(String(ctx.from.id)))[0];
    if (!instance) {
      instance = await instanceService.create({ telegramOwnerId: String(ctx.from.id), label: `WA-${phoneNumber}` });
    }

    await requestPairing(instanceService.instanceDir(instance.instanceId), phoneNumber);
    await processManager.run('start', instance.instanceId).catch(async (err) => {
      await ctx.reply(`❌ فشل بدء الاتصال: ${err.message}`);
      throw err;
    });
    await auditService.record({ developerId: String(ctx.from.id), action: 'user:link', instanceId: instance.instanceId });

    await ctx.reply('⏳ جاري توليد Pairing Code... استخدم "📶 حالة الاتصال" بعد كام ثانية عشان تشوفه.', userMenuKeyboard());
  });
}

function describeStatus(status) {
  const map = {
    'never-started': 'لسه ما اتشغّلش',
    starting: 'بيشتغل...',
    connecting: 'بيحاول يتصل...',
    pairing: status.pairingCode ? `محتاج Pairing Code: ${status.pairingCode}` : 'محتاج Pairing',
    connected: 'متصل ✅',
    disconnected: 'مقطوع',
    error: `خطأ: ${status.error || 'غير معروف'}`,
  };
  return map[status.status] || status.status;
}
