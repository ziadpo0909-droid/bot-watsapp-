import { developerOnly } from '../auth/permissions.js';
import { developerMenuKeyboard } from '../keyboards/developer.js';
import { readRecentLogs, formatLogsForTelegram } from '../services/log-service.js';

/** أوامر عامة للوحة الـDeveloper (مش خاصة بـinstance/plugin/settings معينة) */
export function registerDeveloperHandlers(bot, { auditService }) {
  bot.command('dashboard', developerOnly(), async (ctx) => {
    await ctx.reply('🛠️ لوحة الـDeveloper:', developerMenuKeyboard());
  });

  bot.action('dev:security', developerOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const recent = await auditService.listRecent(15);
    const text = recent.length
      ? recent.map((r) => `[${r.timestamp}] ${r.developerId} → ${r.action} (${r.instanceId || '-'}) : ${r.result}`).join('\n')
      : 'مفيش Audit logs لسه.';
    await ctx.reply(`🛡️ آخر 15 عملية Developer:\n\n${text.slice(0, 3500)}`);
  });
}
