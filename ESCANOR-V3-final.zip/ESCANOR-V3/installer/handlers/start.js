import { isDeveloper } from '../auth/permissions.js';
import { userMenuKeyboard } from '../keyboards/user.js';
import { developerMenuKeyboard } from '../keyboards/developer.js';

export function registerStartHandler(bot) {
  bot.start(async (ctx) => {
    const dev = isDeveloper(ctx.from.id);
    const name = ctx.from.first_name || 'صديقي';
    if (dev) {
      await ctx.reply(`👋 أهلًا ${name} — لوحة الـDeveloper:`, developerMenuKeyboard());
    } else {
      await ctx.reply(`👋 أهلًا ${name} — اربط رقم واتساب:`, userMenuKeyboard());
    }
  });
}
