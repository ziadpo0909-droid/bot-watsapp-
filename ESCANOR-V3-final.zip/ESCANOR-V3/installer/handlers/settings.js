import { developerOnly } from '../auth/permissions.js';
import { loadConfig, saveConfig, getPublicConfig } from '../../src/config/config-manager.js';

const pendingSetting = new Map(); // telegramId -> { instanceId, field }

export function registerSettingsHandlers(bot, { instanceService, auditService }) {
  bot.action('dev:settings', developerOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const instances = await instanceService.list();
    if (!instances.length) return ctx.reply('مفيش instances لسه.');
    const buttons = instances.map((i) => [{ text: i.label, callback_data: `dev:settings:show:${i.instanceId}` }]);
    await ctx.reply('اختار الـinstance:', { reply_markup: { inline_keyboard: buttons } });
  });

  bot.action(/dev:settings:show:(.+)/, developerOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const instanceId = ctx.match[1];
    const config = getPublicConfig(await loadConfig(instanceService.instanceDir(instanceId)));
    await ctx.reply(
      `⚙️ إعدادات ${instanceId}:\n` +
        `الاسم: ${config.botName}\n` +
        `الـPrefix: ${config.prefix}\n` +
        `Owners: ${config.owners.join(', ') || '(مفيش)'}`,
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: '✏️ تغيير الـPrefix', callback_data: `dev:settings:setprefix:${instanceId}` }],
            [{ text: '➕ إضافة Owner', callback_data: `dev:settings:addowner:${instanceId}` }],
          ],
        },
      }
    );
  });

  bot.action(/dev:settings:setprefix:(.+)/, developerOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    pendingSetting.set(ctx.from.id, { instanceId: ctx.match[1], field: 'prefix' });
    await ctx.reply('اكتب الـprefix الجديد (حرف واحد):');
  });

  bot.action(/dev:settings:addowner:(.+)/, developerOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    pendingSetting.set(ctx.from.id, { instanceId: ctx.match[1], field: 'owner' });
    await ctx.reply('ابعت رقم الواتساب (JID أو رقم دولي) اللي هيبقى Owner:');
  });

  bot.on('text', async (ctx, next) => {
    const pending = pendingSetting.get(ctx.from.id);
    if (!pending) return next();
    pendingSetting.delete(ctx.from.id);

    const instanceDir = instanceService.instanceDir(pending.instanceId);
    const config = await loadConfig(instanceDir);

    try {
      if (pending.field === 'prefix') {
        const prefix = ctx.message.text.trim();
        await saveConfig(instanceDir, { ...config, prefix });
      } else if (pending.field === 'owner') {
        const jid = ctx.message.text.trim();
        await saveConfig(instanceDir, { ...config, owners: [...new Set([...config.owners, jid])] });
      }
      await auditService.record({
        developerId: String(ctx.from.id),
        action: `config:${pending.field}`,
        instanceId: pending.instanceId,
        result: 'success',
      });
      await ctx.reply('✅ اتحفظ. (محتاج Restart للـinstance عشان يتطبق)');
    } catch (err) {
      await ctx.reply(`❌ فشل الحفظ: ${err.message}`);
    }
  });
}
