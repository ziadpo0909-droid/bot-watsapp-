import { developerOnly } from '../auth/permissions.js';
import { readRecentLogs, formatLogsForTelegram } from '../services/log-service.js';

export function registerLogHandlers(bot, { instanceService }) {
  bot.action('dev:logs', developerOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const instances = await instanceService.list();
    if (!instances.length) return ctx.reply('مفيش instances لسه.');
    const buttons = instances.map((i) => [{ text: i.label, callback_data: `dev:logs:show:${i.instanceId}` }]);
    await ctx.reply('اختار الـinstance:', { reply_markup: { inline_keyboard: buttons } });
  });

  bot.action(/dev:logs:show:(.+)/, developerOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const instanceId = ctx.match[1];
    const entries = await readRecentLogs(instanceService.instanceDir(instanceId), { limit: 25 });
    await ctx.reply(`📜 آخر logs — ${instanceId}:\n\n${formatLogsForTelegram(entries)}`);
  });
}
