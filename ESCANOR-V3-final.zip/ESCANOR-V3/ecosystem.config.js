/**
 * ecosystem.config.js — تشغيل production عبر PM2.
 * تشغيل: pm2 start ecosystem.config.js
 * ملحوظة: instances/<id> بتتضاف ديناميكيًا عن طريق installer/bot.js (ProcessManager)،
 * الملف ده بس بيشغّل الـTelegram installer نفسه كـprocess ثابت.
 */
export default {
  apps: [
    {
      name: 'escanor_installer',
      script: 'installer/bot.js',
      autorestart: true,
      max_restarts: 10,
      env: { NODE_ENV: 'production' },
    },
  ],
};
