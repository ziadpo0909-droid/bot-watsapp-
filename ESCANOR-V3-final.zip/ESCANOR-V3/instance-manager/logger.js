/**
 * instance-manager/logger.js
 * بيكتب أي log entry (من onLog callbacks بتاعة engine-manager/core) لملف
 * instances/<id>/logs/core.log كـJSON lines، بعد ما يعديها على الـsanitizer.
 * ده اللي بيتقرا بعدين من installer/services/log-service.js لعرضه على Telegram.
 */

import fs from 'node:fs';
import path from 'node:path';
import { sanitizeForLog } from '../src/security/sanitizer.js';

export function createInstanceLogger(instanceDir) {
  const logFile = path.join(instanceDir, 'logs', 'core.log');
  fs.mkdirSync(path.dirname(logFile), { recursive: true });

  return function onLog(entry) {
    const safeMessage = sanitizeForLog(entry.message);
    const line = JSON.stringify({
      ts: new Date().toISOString(),
      level: entry.level || 'info',
      instanceId: entry.instanceId,
      message: safeMessage,
    });
    fs.appendFile(logFile, line + '\n', () => {}); // fire-and-forget، متعمول عشان اللوج ميعطلش رسائل WhatsApp
  };
}
