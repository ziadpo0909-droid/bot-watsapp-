/**
 * instance-manager/json-db.js
 * "قاعدة بيانات" بسيطة كملفات JSON بدل SQLite. القرار ده مقصود:
 * SQLite الأصلي (better-sqlite3 / sqlite3) محتاج compile وقت npm install، ومحتاج
 * اختبار على بيئة حقيقية متصلة بالنت — حاجة معنديش وصول ليها هنا. الملفات دي
 * dependency-free وقابلة للاختبار فورًا، وممكن تتستبدل بـSQLite لاحقًا في Phase 10
 * بدون ما الـcaller (instance-service.js, audit-service.js) يتغير — نفس الـinterface.
 *
 * كل جدول = ملف JSON فيه array. الكتابة atomic (tmp file + rename).
 */

import fs from 'node:fs/promises';
import path from 'node:path';

export class JsonTable {
  constructor(dbDir, tableName) {
    this.file = path.join(dbDir, `${tableName}.json`);
    this._writeLock = Promise.resolve(); // عشان مايحصلش تعارض كتابة متزامنة على نفس الملف
  }

  async _ensureDir() {
    await fs.mkdir(path.dirname(this.file), { recursive: true });
  }

  async readAll() {
    try {
      const raw = await fs.readFile(this.file, 'utf-8');
      return JSON.parse(raw);
    } catch (err) {
      if (err.code === 'ENOENT') return [];
      throw err;
    }
  }

  async _writeAll(rows) {
    await this._ensureDir();
    const tmp = `${this.file}.tmp`;
    await fs.writeFile(tmp, JSON.stringify(rows, null, 2), 'utf-8');
    await fs.rename(tmp, this.file);
  }

  async insert(row) {
    return this._locked(async () => {
      const rows = await this.readAll();
      rows.push(row);
      await this._writeAll(rows);
      return row;
    });
  }

  async update(predicate, updater) {
    return this._locked(async () => {
      const rows = await this.readAll();
      let updated = null;
      const next = rows.map((r) => {
        if (predicate(r)) {
          updated = { ...r, ...updater(r) };
          return updated;
        }
        return r;
      });
      await this._writeAll(next);
      return updated;
    });
  }

  async remove(predicate) {
    return this._locked(async () => {
      const rows = await this.readAll();
      const next = rows.filter((r) => !predicate(r));
      const removedCount = rows.length - next.length;
      await this._writeAll(next);
      return removedCount;
    });
  }

  async find(predicate) {
    const rows = await this.readAll();
    return rows.filter(predicate);
  }

  async findOne(predicate) {
    const rows = await this.readAll();
    return rows.find(predicate) ?? null;
  }

  /** بيسلسل كل عمليات الكتابة على نفس الجدول عشان نتفادى race condition بين طلبين Telegram في نفس اللحظة */
  _locked(fn) {
    const run = this._writeLock.then(fn, fn);
    this._writeLock = run.catch(() => {});
    return run;
  }
}
