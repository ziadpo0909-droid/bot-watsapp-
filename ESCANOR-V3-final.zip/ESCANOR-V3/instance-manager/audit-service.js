/**
 * instance-manager/audit-service.js
 * تسجيل كل عملية Developer (من Telegram) — instance actions, config changes, plugin toggles، إلخ.
 */

import { JsonTable } from './json-db.js';
import { sanitizeForLog } from '../src/security/sanitizer.js';

export class AuditService {
  constructor(dbDir) {
    this.table = new JsonTable(dbDir, 'audit_logs');
  }

  async record({ developerId, action, instanceId = null, result = 'success', details = null }) {
    return this.table.insert({
      id: `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      timestamp: new Date().toISOString(),
      developerId,
      action,
      instanceId,
      result,
      details: details ? sanitizeForLog(details) : null,
    });
  }

  async listRecent(limit = 50) {
    const rows = await this.table.readAll();
    return rows.slice(-limit).reverse();
  }

  async listByInstance(instanceId, limit = 50) {
    const rows = await this.table.find((r) => r.instanceId === instanceId);
    return rows.slice(-limit).reverse();
  }
}
