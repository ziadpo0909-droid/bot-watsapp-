/**
 * instance-manager/instance-service.js
 * إدارة instances على مستوى الـfilesystem + سجل في JsonTable.
 * كل instance = فولدر instances/<id>/{session,config,data,logs}.
 */

import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { JsonTable } from './json-db.js';
import { createInitialConfig } from '../src/config/config-manager.js';

export class InstanceService {
  constructor({ instancesRoot, dbDir }) {
    this.instancesRoot = instancesRoot;
    this.table = new JsonTable(dbDir, 'instances');
  }

  instanceDir(instanceId) {
    return path.join(this.instancesRoot, instanceId);
  }

  async create({ telegramOwnerId, label = null }) {
    const instanceId = `instance_${crypto.randomBytes(4).toString('hex')}`;
    const dir = this.instanceDir(instanceId);

    for (const sub of ['session', 'config', 'data', 'logs']) {
      await fs.mkdir(path.join(dir, sub), { recursive: true });
    }
    await createInitialConfig(dir, instanceId, { botName: label || instanceId });

    const record = {
      instanceId,
      telegramOwnerId,
      label: label || instanceId,
      status: 'disconnected',
      createdAt: new Date().toISOString(),
    };
    await this.table.insert(record);
    return record;
  }

  async list(telegramOwnerId = null) {
    const rows = await this.table.readAll();
    return telegramOwnerId ? rows.filter((r) => r.telegramOwnerId === telegramOwnerId) : rows;
  }

  async get(instanceId) {
    return this.table.findOne((r) => r.instanceId === instanceId);
  }

  async setStatus(instanceId, status) {
    return this.table.update((r) => r.instanceId === instanceId, () => ({ status }));
  }

  async delete(instanceId) {
    const removed = await this.table.remove((r) => r.instanceId === instanceId);
    if (removed > 0) {
      await fs.rm(this.instanceDir(instanceId), { recursive: true, force: true });
    }
    return removed > 0;
  }

  /** يمنع Developer من إدارة instance ملهوش صلاحية عليه */
  async assertOwnership(instanceId, telegramOwnerId, isDeveloper) {
    const record = await this.get(instanceId);
    if (!record) throw new Error('instance غير موجود');
    if (!isDeveloper && record.telegramOwnerId !== telegramOwnerId) {
      throw new Error('ملكش صلاحية على الـinstance ده');
    }
    return record;
  }
}
