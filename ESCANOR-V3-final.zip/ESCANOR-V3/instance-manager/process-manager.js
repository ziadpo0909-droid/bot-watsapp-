/**
 * instance-manager/process-manager.js
 * Wrapper حول PM2 API (لا exec(user_input) هنا خالص). العمليات المسموح بيها
 * محدودة بالـALLOWED_ACTIONS بس، وكل عملية بتاخد instanceId بس (مش أي أمر حر).
 *
 * الاعتماد على pm2 متعمول عن طريق Dependency Injection (opts.pm2Client) عشان:
 *   1. نقدر نختبر المنطق هنا بدون ما نحتاج pm2 حقيقي متصل.
 *   2. في production، الـcaller (installer/services) بيبعت import('pm2') الحقيقي.
 */

const ALLOWED_ACTIONS = Object.freeze(['start', 'stop', 'restart', 'status', 'logs', 'delete']);

export class ProcessManager {
  /**
   * @param {object} opts
   * @param {object} opts.pm2Client - أي object فيه: connect, start, stop, restart, delete, describe, disconnect (زي مكتبة pm2 نفسها)
   * @param {string} opts.scriptPath - المسار اللي هيتشغل بيه كل instance (src/core-runner.js مثلًا)
   */
  constructor({ pm2Client, scriptPath }) {
    if (!pm2Client) throw new Error('pm2Client مطلوب (Dependency Injection)');
    this.pm2 = pm2Client;
    this.scriptPath = scriptPath;
  }

  _processName(instanceId) {
    return `escanor_${instanceId}`;
  }

  async _withConnection(fn) {
    return new Promise((resolve, reject) => {
      this.pm2.connect((err) => {
        if (err) return reject(err);
        fn()
          .then((result) => {
            this.pm2.disconnect();
            resolve(result);
          })
          .catch((error) => {
            this.pm2.disconnect();
            reject(error);
          });
      });
    });
  }

  async run(action, instanceId, extra = {}) {
    if (!ALLOWED_ACTIONS.includes(action)) {
      throw new Error(`عملية غير مسموح بيها: ${action}`);
    }
    if (!instanceId || typeof instanceId !== 'string') {
      throw new Error('instanceId مطلوب');
    }
    const name = this._processName(instanceId);

    return this._withConnection(async () => {
      switch (action) {
        case 'start':
          return this._promisify(this.pm2.start, {
            name,
            script: this.scriptPath,
            args: [instanceId],
            env: { INSTANCE_ID: instanceId, ...extra.env },
            autorestart: true,
            max_restarts: 10,
          });
        case 'stop':
          return this._promisify(this.pm2.stop, name);
        case 'restart':
          return this._promisify(this.pm2.restart, name);
        case 'delete':
          return this._promisify(this.pm2.delete, name);
        case 'status':
          return this._promisify(this.pm2.describe, name);
        case 'logs':
          return this._promisify(this.pm2.describe, name); // logs الفعلية هتتقرا من ملف اللوج عن طريق log-service، مش من PM2 stdout مباشرة
        default:
          throw new Error(`عملية غير مدعومة: ${action}`);
      }
    });
  }

  _promisify(fn, ...args) {
    return new Promise((resolve, reject) => {
      fn.call(this.pm2, ...args, (err, result) => (err ? reject(err) : resolve(result)));
    });
  }
}
